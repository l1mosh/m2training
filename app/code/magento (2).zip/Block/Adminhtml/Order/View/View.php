<?php
namespace Superpayments\SuperPayment\Block\Adminhtml\Order\View;

class View extends \Magento\Backend\Block\Template
{
    public function myFunction()
    {

        return "QouteID";
    }
}