<?php

namespace Superpayments\SuperPayment\Block\Order\Invoice;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Directory\Model\CurrencyFactory;

class Totals extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Prince\Extrafee\Helper\Data
     */
    protected $_helper;
    /**
     * @var \Magento\Sales\Model\Order\Invoice
     */
    protected $_invoice = null;
    /**
     * @var \Magento\Framework\DataObject
     */
    protected $_source;
    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Prince\Extrafee\Helper\Data $helper
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        StoreManagerInterface $storeConfig,
        CurrencyFactory $currencyFactory,
        \Superpayments\SuperPayment\Model\ResourceModel\Post\CollectionFactory $CollectionFactory,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        array $data = []
    ) {
        $this->storeConfig = $storeConfig;
        $this->currencyCode = $currencyFactory->create();
        $this->collectionFactory = $CollectionFactory;
        $this->orderRepository = $orderRepository;
        parent::__construct($context, $data);
    }
    public function getSource()
    {
        return $this->getParentBlock()->getSource();
    }
    public function getInvoice()
    {
        return $this->getParentBlock()->getInvoice();
    }
    public function initTotals()
    {
        $parent = $this->getParentBlock();
        $invoice = $this->getInvoice();
        $order_id = $invoice->getOrderId();
        $order = $this->orderRepository->get($order_id);
                $payment = $order->getPayment();
        if ( $payment->getMethod() == "super_payment_gateway" ) {
        $collectionSavingAmount = $this->collectionFactory->create()->addFieldToFilter('order_increment_id', $order_id)->getColumnValues('saving_amount');
        $collectionAmountafter = $this->collectionFactory->create()->addFieldToFilter('order_increment_id', $order_id)->getColumnValues('amountafter_saving');
        $new_grand_total = isset($collectionAmountafter[0]) ? $amountafter_saving = $collectionAmountafter[0] : $amountafter_saving = "";
        isset($collectionSavingAmount[0]) ? $saving_amount = $collectionSavingAmount[0] : $saving_amount = "";
        $total = new \Magento\Framework\DataObject(
            [
                'code' => 'discount',
                'value' => -$saving_amount,
                'label' => 'Instant Cashback',
            ]
        );
        
        $parent->addTotal($total, 'discount');
    }
        return $this;
    }
}