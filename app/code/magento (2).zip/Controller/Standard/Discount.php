<?php

namespace Superpayments\SuperPayment\Controller\Standard;

use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;

class Discount extends \Magento\Framework\App\Action\Action implements CsrfAwareActionInterface
{
    protected $_coreRegistry;

    protected $_checkoutSession;
    protected $SuperpaymentModelFactory;

    protected $_orderFactory;

    private $quoteFactory;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    private $jsonResultFactory;

    protected $helperData;

    public function createCsrfValidationException(
        RequestInterface $request
    ): ?InvalidRequestException {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    protected $_pageFactory;
    protected $_postFactory;
    protected $CollectionFactory;
    protected $collectionFactory;
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Checkout\Model\Cart $checkoutSession,
        \Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Magento\Framework\Controller\Result\JsonFactory $jsonResultFactory,
        \Superpayments\SuperPayment\Helper\Data $helperData,
        \Superpayments\SuperPayment\Model\PostFactory $postFactory,
        \Superpayments\SuperPayment\Model\ResourceModel\Post\CollectionFactory $CollectionFactory
    )
    {
        $this->_coreRegistry = $coreRegistry;
        $this->_pageFactory = $pageFactory;
        $this->_checkoutSession = $checkoutSession;
        $this->quoteFactory = $quoteFactory;
        $this->_orderFactory = $orderFactory;
        $this->jsonResultFactory = $jsonResultFactory;
        $this->helperData = $helperData;
        $this->_postFactory = $postFactory;
        $this->collectionFactory = $CollectionFactory;
        return parent::__construct($context);
    }

    /**
     * Get order object
     *
     * @return \Magento\Sales\Model\Order
     */
    public function execute()
    {

        $res = $this->getApiResponse();
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom_webhook.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info($res);


        $data = array();
        if(isset($res['errorMessage']))
        { //errorMessage Unauthorized

            $errorMessage = "Error: Super Payment ". $res['errorMessage'].". Please check api keys.";
            $data = ['errorMessage' => $errorMessage , 'error' => 1];
            $result = $this->jsonResultFactory->create();
            $result->setData($data);
            return $result;
        }

        $data = array();
        if (!empty($res)) {
            if(isset($res['content']) && isset($res['content']['description'])){
                $description = $res['content']['description'];
                $title = $res['content']['title'];
                $data = ['title' => $title , 'description' => $description];
            }
        }

        $result = $this->jsonResultFactory->create();
        $result->setData($data);
        return $result;
    }

    public function getApiResponse(){
        try {
            $quoteId = (int)$this->_checkoutSession->getQuote()->getId();
            $quoteData = $this->quoteFactory->create()->load($quoteId);
            $items =$this->_checkoutSession->getQuote()->getAllVisibleItems();
            $itemData = [];
            $grandtotal = $quoteData->getGrandTotal();
            $item_total = max( 0, (float) $grandtotal );
            $item_total_minor_unit = round( $item_total * 100 );
            $itemData['minorUnitAmount'] = $item_total_minor_unit;
            $itemData['cart']['id'] = (string)$quoteId;
            foreach ($items as $item) {
                $product = $item->getProduct();
                $itemamount = $item->getPrice();
                $item_amount = max( 0, (float) $itemamount );
                $item_minor_unit = round( $item_amount * 100 );
                $itemData['cart']['items'][] = [
                    'name'=>$item->getName(),
                    'quantity'=>$item->getQty(),
                    'url'=>$product->getUrlModel()->getUrl($product),
                    'minorUnitAmount'=> $item_minor_unit

                ];
                break;
            }
            $itemData['page'] = 'Checkout';
            $itemData['output'] = 'both';
            if ($this->helperData->getChecksanbox() == 1) {
                $itemData['test'] = true;
            }
            else {
                $itemData['test'] = false;
            }
            $ApiUrl = $this->helperData->getOfferApi();
            $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom_webhook.log');
            $logger = new \Zend_Log();
            $logger->addWriter($writer);
            $logger->info($ApiUrl);
            $response = $this->helperData->getOfferApiResponse($itemData , $ApiUrl);
            $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom_webhook.log');
            $logger = new \Zend_Log();
            $logger->addWriter($writer);
            $logger->info($response);
            $logger->info('Quote id is'.$quoteId);
            $response = json_decode($response , true);


            if(isset($response['errorMessage']))
            {
                return $response;
            }

            $post = $this->_postFactory->create();
            $collection = $this->collectionFactory->create();

            $collection = $collection->addFieldToFilter('quote_id', $quoteId);
            if ($collection->count() > 0) {
                $postUpdate = $post->load($quoteId,'quote_id');
                $postUpdate->setCashbackOfferId($response['cashbackOfferId']);
                $postUpdate->setAmountafterSaving($response['calculation']['amountAfterSavings']);
                $postUpdate->setGrossAmount($response['calculation']['grossAmount']);
                $postUpdate->setSavingAmount($response['calculation']['savingsAmount']);
                $postUpdate->setSavingPercentage($response['calculation']['savingsPercentage']);
                $postUpdate->save();
            } else {
                if (isset($response['cashbackOfferId']) && isset($response['calculation'])) {
                    $post->setQuoteId($quoteId);
                    $post->setCashbackOfferId($response['cashbackOfferId']);
                    $post->setAmountafterSaving($response['calculation']['amountAfterSavings']);
                    $post->setGrossAmount($response['calculation']['grossAmount']);
                    $post->setSavingAmount($response['calculation']['savingsAmount']);
                    $post->setSavingPercentage($response['calculation']['savingsPercentage']);
                    $post->save();
                }
            }
            return $response;
        }catch(Exception $e){

        }
    }

}
