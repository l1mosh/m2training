<?php

namespace Superpayments\SuperPayment\Controller\Standard;

use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Controller\ResultFactory;

class Redirect extends \Magento\Framework\App\Action\Action implements CsrfAwareActionInterface
{
    protected $_coreRegistry;
    protected $storeManager;
    protected $_checkoutSession;
    protected $_orderFactory;
    protected $resultFactory;
    protected $_helper;
    protected $_postFactory;
    protected $collectionFactory;
    protected $_messageManager;
    protected $quoteFactory;
    protected $_response;
    protected $_responseFactory;
    protected $jsonHelper;
    protected $_cartSession;
    protected $quoteRepository;
    protected $quoteManagement;

    public function createCsrfValidationException(
        RequestInterface $request
    ): ?InvalidRequestException
    {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    protected $_pageFactory;

    public function __construct(
        \Magento\Framework\App\Action\Context                                  $context,
        \Magento\Quote\Api\CartRepositoryInterface                             $quoteRepository,
        \Magento\Framework\Registry                                            $coreRegistry,
        \Magento\Checkout\Model\Session                                        $checkoutSession,
        \Magento\Sales\Model\OrderFactory                                      $orderFactory,
        \Magento\Framework\View\Result\PageFactory                             $pageFactory,
        \Superpayments\SuperPayment\Helper\Data                                $helper,
        \Magento\Quote\Api\CartManagementInterface                             $quoteManagement,
        StoreManagerInterface                                                  $storeManager,
        \Magento\Framework\Controller\ResultFactory                            $resultFactory,
        \Superpayments\SuperPayment\Model\PostFactory                          $postFactory,
        \Superpayments\SuperPayment\Model\ResourceModel\Post\CollectionFactory $CollectionFactory,
        \Magento\Framework\Message\ManagerInterface                            $messageManager,
        \Magento\Quote\Model\QuoteFactory                                      $quoteFactory,
        \Magento\Framework\App\Response\Http                                   $response,
        \Magento\Framework\App\ResponseFactory                                 $responseFactory,
        \Magento\Framework\Json\Helper\Data                                    $jsonHelper,
        \Magento\Checkout\Model\Cart                                           $checkoutsession
    )
    {
        $this->_coreRegistry = $coreRegistry;
        $this->_pageFactory = $pageFactory;
        $this->quoteManagement = $quoteManagement;
        $this->_checkoutSession = $checkoutSession;
        $this->_orderFactory = $orderFactory;
        $this->quoteRepository = $quoteRepository;
        $this->_helper = $helper;
        $this->storeManager = $storeManager;
        $this->resultFactory = $resultFactory;
        $this->_postFactory = $postFactory;
        $this->collectionFactory = $CollectionFactory;
        $this->_messageManager = $messageManager;
        $this->quoteFactory = $quoteFactory;
        $this->_response = $response;
        $this->_responseFactory = $responseFactory;
        $this->jsonHelper = $jsonHelper;
        $this->_cartSession = $checkoutsession;
        return parent::__construct($context);
    }


    public function execute()
    {
        //$quoteId = $this->getRequest()->getParam('quoteId');
        //$qoute_collection = $this->collectionFactory->create()->getLastItem();
        //$quoteId = $qoute_collection->getQuoteId();
        $quoteId = $this->_cartSession->getQuote()->getId();
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom_webhook_new_redirect.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        //$logger->info($response);
        $logger->info('Quote id is new' . $quoteId);
        try {
            if ($quoteId) {
                $BaseUrl = $this->storeManager->getStore()->getBaseUrl();
                $quote = $this->quoteFactory->create()->load($quoteId);
                if ($quote->getCustomerEmail() == '') {

                    $email = $quote->getBillingAddress()->getEmail();
                    $quote = $this->quoteRepository->get($quoteId);

                    if (!$quote->getCustomerId())
                        $quote->setCustomerIsGuest(true);

                    $quote->setCustomerEmail($email);
                    $this->quoteRepository->save($quote);
                    $quote = $this->quoteFactory->create()->load($quoteId);

                }


                $orderdata = $this->quoteManagement->submit($quote);
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $customerSession = $objectManager->create('Magento\Customer\Model\Session');
                $customerSession->setMyValue($orderdata->getLastRealOrderId());

                $customerSession->setMyValude($orderdata->getLastOrderId());
                //$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $customerSession = $objectManager->create('Magento\Customer\Model\Session');
                $post = $this->_postFactory->create();
                $collection = $this->collectionFactory->create();
                $collectionOffer = $collection->addFieldToFilter('quote_id', $quoteId)->getColumnValues('cashback_offer_id');
                isset($collectionOffer[0]) ? $cashback_offer_id = $collectionOffer[0] : $cashback_offer_id = "";
                $quoteAmount = $quote->getGrandTotal();
                $item_total = max(0, (float)$quoteAmount);
                $item_total_minor_unit = round($item_total * 100);
                $logger->info('Amount is' . $item_total_minor_unit);
                $ApiData = [];
                $ApiData['cashbackOfferId'] = $cashback_offer_id;
                $ApiData['successUrl'] = $BaseUrl . "checkout/onepage/success/?id=".$orderdata->getIncrementId();
                $ApiData['cancelUrl'] = $BaseUrl . "checkout/cart/?id=".$orderdata->getIncrementId();
                $ApiData['failureUrl'] = $BaseUrl . "checkout/cart/?id=".$orderdata->getIncrementId();
                $ApiData['minorUnitAmount'] = $item_total_minor_unit;
                $ApiData['currency'] = $this->_helper->getCurrentCurrencyCode();
                //$ApiData['currency'] ='USD';
                $ApiData['externalReference'] = $orderdata->getIncrementId();
                if ($this->_helper->getChecksanbox() == 1) {
                    $ApiData['test'] = true;
                } else {
                    $ApiData['test'] = false;
                }
                $ApiUrl = $this->_helper->getPaymentApi();
                $response = $this->_helper->getOfferApiResponse($ApiData, $ApiUrl);
                $logger->info('request is' . json_encode($ApiData));
                $logger->info('Respone is' . $response);
                $response = json_decode($response, true);
                $collection = $collection->addFieldToFilter('quote_id', $quoteId);
                if ($collection->count() > 0) {
                    $postUpdate = $post->load($quoteId, 'quote_id');
                    //$postUpdate->setOrderIncrementId($this->getOrderId());
                    if (isset($response['redirectUrl']) && $response['transactionId'] && $response['transactionReference']) {
                        $postUpdate->setRedirectUrl($response['redirectUrl']);
                        $postUpdate->setTransactionId($response['transactionId']);
                        $postUpdate->setTransactionReference($response['transactionReference']);
                    }

                    $postUpdate->save();
                }
                $response1 = $this->resultFactory->create(ResultFactory::TYPE_RAW);
                $response1->setHeader('Content-type', 'text/plain');
                if (isset($response['redirectUrl'])) {
                    $response1->setContents(
                        $this->jsonHelper->jsonEncode(['success' => true, 'redirect_url' => $response['redirectUrl']])
                    );
                    return $response1;

                } else {
                    $response1->setContents(
                        $this->jsonHelper->jsonEncode(
                            [
                                'success' => false,
                                'apiError' => "Super Payment: " . $response['errorMessage']
                            ]
                        )
                    );
                    return $response1;
                }
            }
        } catch (\Exception $e) {
            $response1 = $this->resultFactory->create(ResultFactory::TYPE_RAW);
            $response1->setHeader('Content-type', 'text/plain');
            $response1->setContents(
                $this->jsonHelper->jsonEncode(
                    [
                        'success' => false,
                        'apiError' => "Super Payment: " . $response['errorMessage']." Exception ".$e
                    ]
                )
            );
            return $response1;
        }
    }
}