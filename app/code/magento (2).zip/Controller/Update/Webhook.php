<?php

namespace Superpayments\SuperPayment\Controller\Update;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Framework\DB\Transaction;
use Magento\Sales\Model\Order\Email\Sender\InvoiceSender;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Directory\Model\CurrencyFactory;
class Webhook extends \Magento\Framework\App\Action\Action implements CsrfAwareActionInterface
{
    protected $orderRepository;
    protected $invoiceService;
    protected $transaction;
    protected $invoiceSender;
    protected $_resource;
    

    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;
    /**
     * @param Context     $context
     * @param JsonFactory $resultJsonFactory
     */
    public function __construct(
        Context $context,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        InvoiceService $invoiceService,
        InvoiceSender $invoiceSender,
        Transaction $transaction,
        \Magento\Framework\App\ResourceConnection $resource,
        \Superpayments\Superpayment\Helper\Data $helperData,
        \Superpayments\SuperPayment\Model\PostFactory $postFactory,
        \Superpayments\SuperPayment\Model\ResourceModel\Post\CollectionFactory $CollectionFactory,
        JsonFactory $resultJsonFactory,
        StoreManagerInterface $storeConfig,
        CurrencyFactory $currencyFactory,
        \Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Quote\Model\QuoteManagement $quoteManagement,
        \Magento\Framework\Controller\ResultFactory $resultFactory,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\Framework\App\ResponseInterface $jsonresponseFactory,
        \Magento\Checkout\Model\Session $checkoutSession   
    ) {
        $this->resultJsonFactory = $resultJsonFactory;
        $this->orderRepository = $orderRepository;
        $this->invoiceService = $invoiceService;
        $this->invoiceSender = $invoiceSender;
        $this->transaction = $transaction;
        $this->_resource = $resource;
        $this->_postFactory = $postFactory;
         $this->collectionFactory = $CollectionFactory;
        $this->helperData = $helperData;
        $this->storeConfig = $storeConfig;
        $this->currencyCode = $currencyFactory->create();
        $this->quoteFactory = $quoteFactory;
        $this->quoteManagement = $quoteManagement;
        $this->resultFactory = $resultFactory;
        $this->_orderCollectionFactory = $orderCollectionFactory;
        $this->jsonresponseFactory = $jsonresponseFactory;
        $this->_checkoutSession = $checkoutSession;
        parent::__construct($context);
    }
	public function createCsrfValidationException(RequestInterface $request): ? InvalidRequestException
	{
		return null;
	}

	public function validateForCsrf(RequestInterface $request): ?bool
	{
		return true;
	}
	public function execute()
	{
    //ss$quote_id = 578;
              //          $this->_checkoutSession->setQuoteId($quote_id);
              //          $quote = $this->quoteFactory->create()->load($quote_id);
              // $orderdata = $this->quoteManagement->submit($quote);
              // $orderdata->setEmailSent(0);
              // $this->_checkoutSession->setLastSuccessQuoteId($quote_id);
              // $this->_checkoutSession->setLastQuoteId($quote_id);
              // $this->_checkoutSession->setLastOrderId($orderdata->getEntityId());
              // $order_id = $orderdata->getEntityId();
              //$resultRedirect = $this->resultRedirectFactory->create();
//$resultRedirect->setPath('checkout/onepage/success');
//return $resultRedirect;s
              //die('only testing');   
            $BaseUrl = $this->storeConfig->getStore()->getBaseUrl();    
            $request_body = file_get_contents( 'php://input' );
            $parsed_json = json_decode( $request_body );
            $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom_webhook_new.log');
            $logger = new \Zend_Log();
            $logger->addWriter($writer);
            $logger->info($request_body);
             $signature_header = filter_var( $_SERVER['HTTP_SUPER_SIGNATURE'] );
             $signature_header_parts = explode( ",", $signature_header );
             $timestamp_parts = explode( ":", $signature_header_parts[0] );
             $signature_parts = explode( ":", $signature_header_parts[1] );
			 
			 $resultJson = $this->resultJsonFactory->create();
			 if(!isset($timestamp_parts[1]))
          return $this->jsonresponseFactory->setStatusCode(\Magento\Framework\App\Response\Http::STATUS_CODE_400)->setContent('400');   
             $Apikey = $this->helperData->getConfirmApiKey();
             $generated_signature = $this->generateSignature( $request_body, $timestamp_parts[1], $Apikey );
			 $logger->info('Line number 100');
			if ( $generated_signature != $signature_parts[1] ) { 
                return $this->jsonresponseFactory->setStatusCode(\Magento\Framework\App\Response\Http::STATUS_CODE_401)->setContent('401'); 
            }
        $logger->info('Line number 104');    
             $quote_id = filter_var( $parsed_json->externalReference, FILTER_SANITIZE_NUMBER_INT );
            
             $payment_status = $parsed_json->transactionStatus;
			        $transaction_amount = $parsed_json->transactionAmount;
              $transaction_id = $parsed_json->transactionId;
              $transaction_reference = $parsed_json->transactionReference;
					
             if ( !$quote_id ) {
              return $this->jsonresponseFactory->setStatusCode(\Magento\Framework\App\Response\Http::STATUS_CODE_400)->setContent('400');
            }

              $quote = $this->quoteFactory->create()->load($quote_id);
             if ( !$quote ) {
                 return $this->jsonresponseFactory->setStatusCode(\Magento\Framework\App\Response\Http::STATUS_CODE_404)->setContent('404'); 
            }
            if ( $quote->getPayment()->getMethod() != "super_payment_gateway" ) {
              return $this->jsonresponseFactory->setStatusCode(\Magento\Framework\App\Response\Http::STATUS_CODE_403)->setContent('403');
            }
            switch ( $payment_status ) {
                case 'PaymentSuccess':
                $logger->info('Line number 125 is'.$quote_id);
              $logger->info('Line number 126');
              $collection = $this->_orderCollectionFactory->create()->addAttributeToSelect('*')->addFieldToFilter('quote_id', ['eq' => $quote_id]);
              if ($collection->count() == 0) {
                $logger->info('Line number 128');
              //$status = STATE_PROCESSING;
              $status = 'PROCESSING';
              $orderdata = $this->quoteManagement->submit($quote);
              $this->_checkoutSession->setLastSuccessQuoteId($quote_id);
              $this->_checkoutSession->setLastQuoteId($quote_id);
              $this->_checkoutSession->setLastOrderId($orderdata->getEntityId());
              $order_id = $orderdata->getEntityId();
              $createOrder = $this->createOrder($order_id,$status,$transaction_amount,$transaction_id,$transaction_reference);
      }
      $logger->info('Line number 129');
              break;
                case 'PaymentCancelled':
                case 'PaymentFailed':
                case 'PaymentAbandoned':
                case 'PaymentDelayed':
              $collection = $this->_orderCollectionFactory->create()->addAttributeToSelect('*')->addFieldToFilter('quote_id', ['eq' => $quote_id]);
              if ($collection->count() == 0) {
              $orderdata = $this->quoteManagement->submit($quote);
              $order_id = $orderdata->getEntityId();
              //$status = STATE_HOLDED;
              $status = 'HOLDED';
              $this->_checkoutSession->setQuoteId($quote_id);
              $orderdata = $this->quoteManagement->submit($quote);
              $this->_checkoutSession->setLastSuccessQuoteId($quote_id);
              $this->_checkoutSession->setLastQuoteId($quote_id);
              $this->_checkoutSession->setLastOrderId($orderdata->getEntityId());
              $order_id = $orderdata->getEntityId();
              $logger->info('Line number 144');
              $createOrder = $this->createOrder($order_id,$status,$transaction_amount,$transaction_id,$transaction_reference);
              $logger->info('Line number 146');
              }
              break;
                case 'PaymentRefunded':
							default:
                return $this->jsonresponseFactory->setStatusCode(\Magento\Framework\App\Response\Http::STATUS_CODE_400)->setContent('400'); 

						}
          return $this->jsonresponseFactory->setStatusCode(\Magento\Framework\App\Response\Http::STATUS_CODE_200)->setContent('200');
	}
    public function createOrder($order_id,$status,$transaction_amount,$transaction_id,$transaction_reference)
        {
              $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom_webhook_function.log');
              $logger = new \Zend_Log();
              $logger->addWriter($writer);
              $logger->info('Line number 161');
              $order = $this->orderRepository->get($order_id);
              $logger->info('Line number 163');
              
              $transaction_amount = $transaction_amount / 100;
              $logger->info('Line number 166');
              $saving_amount_after = $order->getGrandTotal() - $transaction_amount;
              $post = $this->_postFactory->create();
              $logger->info('Line number 169');
              $postUpdate = $post->load($order->getQuoteId(),'quote_id');
              $postUpdate->setAmountafterSaving($transaction_amount);
              $postUpdate->setSavingAmount($saving_amount_after);
              $postUpdate->setOrderIncrementId($order_id);
              $postUpdate->save();
              $logger->info('Line number 172');
              $collection = $this->collectionFactory->create();
              $collectionCashbackOfferId = $collection->addFieldToFilter('quote_id', $order->getQuoteId())->getColumnValues('cashback_offer_id');
              $collectionSavingAmount = $collection->addFieldToFilter('quote_id', $order->getQuoteId())->getColumnValues('saving_amount');
              $collectionAmountafter = $collection->addFieldToFilter('quote_id', $order->getQuoteId())->getColumnValues('amountafter_saving');
              $new_grand_total = isset($collectionAmountafter[0]) ? $amountafter_saving = $collectionAmountafter[0] : $amountafter_saving = "";
              isset($collectionCashbackOfferId[0]) ? $cashback_offer_id = $collectionCashbackOfferId[0] : $cashback_offer_id = "";
              isset($collectionCashbackOfferId[0]) ? $saving_amount = $collectionSavingAmount[0] : $saving_amount = "";
              $currentCurrency = $this->storeConfig->getStore()->getCurrentCurrencyCode();
              $currency = $this->currencyCode->load($currentCurrency);
              $currencySymbol = $currency->getCurrencySymbol();
              $logger->info('Line number 182');
              $order->addStatusHistoryComment('Transaction Id : '.$transaction_id);
              $order->addStatusHistoryComment('Transaction Reference : '.$transaction_reference);
              $order->addStatusHistoryComment('Transaction Amount : '.$currencySymbol.number_format($transaction_amount, 2, '.', ''));
              $order->addStatusHistoryComment('Cashback Offer Id : '.$cashback_offer_id);
              $order->setDiscountAmount($currencySymbol.'-'.number_format($saving_amount, 2, '.', ''));
              $order->setGrandTotal($new_grand_total);
              $order->setBaseGrandTotal($new_grand_total);
              $order->setTotalPaid($new_grand_total);
               ;
              if ($status == 'PROCESSING') {
                  $order->setState(\Magento\Sales\Model\Order::STATE_PROCESSING, true);
                  $order->setStatus(\Magento\Sales\Model\Order::STATE_PROCESSING);
              }
              if ($status == 'HOLDED') {
                  $order->setState(\Magento\Sales\Model\Order::STATE_HOLDED, true);
                  $order->setStatus(\Magento\Sales\Model\Order::STATE_HOLDED);
              }
              $order->save();
              $ApiUrl = $this->helperData->getOfferApi();
              $ApiUrl = $ApiUrl."/".$cashback_offer_id."/expire";
              $ApiData = array();
              $responseexpire = $this->helperData->getOfferApiResponse($ApiData, $ApiUrl);
              $logger->info("expire-".$responseexpire);
              $logger->info('Line number 192');
        }

            public function generateSignature( $message, $timestamp, $secret ) {

                $payload = $timestamp . $message;
                $signature = base64_encode(
                    hash_hmac( 'sha256', $payload, $secret, true )
                );

                return $signature;
            }        
}