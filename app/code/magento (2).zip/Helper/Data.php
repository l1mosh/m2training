<?php

namespace Superpayments\SuperPayment\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Directory\Model\Currency;
use Magento\Directory\Model\CurrencyFactory;

class Data extends AbstractHelper
{
    protected $request;

    protected $context;
    protected $scopeConfig;
    protected $_storeManager;
    protected $_currency;
    protected $checkoutsession;
    protected $quoteFactory;

    protected $currencyCode;
    protected $httpHeader;


    public function __construct(
        \Magento\Framework\App\Helper\Context              $context,
        StoreManagerInterface                              $storeManager,
        Currency                                           $currency,
        \Magento\Framework\HTTP\Header                     $httpHeader,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        CurrencyFactory                                    $currencyFactory,
        \Magento\Framework\App\Request\Http                $request,
        \Magento\Checkout\Model\Session                    $checkoutsession,

        \Magento\Quote\Model\QuoteFactory                  $quoteFactory
    )
    {
        $this->scopeConfig = $scopeConfig;
        $this->_storeManager = $storeManager;
        $this->_currency = $currency;
        $this->httpHeader = $httpHeader;
        $this->currencyCode = $currencyFactory->create();
        $this->context = $context;
        $this->request = $request;
        $this->checkoutsession = $checkoutsession;
        $this->quoteFactory = $quoteFactory;
        parent::__construct($context);
    }

    /**
     * Get current store currency code
     *
     * @return string
     */
    public function getCurrentCurrencyCode()
    {
        return $this->_storeManager->getStore()->getCurrentCurrencyCode();
    }

    public function getConfigValue($path, $storeScope)
    {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;

        return $this->scopeConfig->getValue('payment/super_payment_gateway/' . $path, $storeScope);
    }

    public function getCurrentPage()
    {
        return $this->request->getFullActionName();
    }

    /* check pages API */
    public function CheckListpageApi()
    {
        return $this->scopeConfig->getValue('payment/super_payment_gateway/payment_api_pages/api_listpage',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function checksendemailflag()
    {
        return $this->scopeConfig->getValue('sales_email/order/enabled',\Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function CheckDetailpageApi()
    {
        return $this->scopeConfig->getValue('payment/super_payment_gateway/payment_api_pages/api_detailpage',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function CheckCartpageApi()
    {
        return $this->scopeConfig->getValue('payment/super_payment_gateway/payment_api_pages/api_cartpage',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getOfferContentConfig()
    {
        return $this->scopeConfig->getValue('payment/super_payment_gateway/payment_api_pages/banner_mode',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getOfferBannerColour()
    {
        return $this->scopeConfig->getValue('payment/super_payment_gateway/payment_api_pages/banner_color',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /* Check User Agent*/
    public function getUserAgent()
    {
        return $this->httpHeader->getHttpUserAgent();
    }

    public function getApikey()
    {
        return $this->scopeConfig->getValue('payment/super_payment_gateway/apikey',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getChecksanbox()
    {
        return $this->scopeConfig->getValue('payment/super_payment_gateway/payment_developer_settings/mode',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getConfirmApiKey()
    {
        return $this->scopeConfig->getValue('payment/super_payment_gateway/confirmapikey',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getModuleVersion()
    {
        return $this->scopeConfig->getValue('payment/super_payment_gateway/version',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    public function getMagentoVersion()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $productMetadata = $objectManager->get('Magento\Framework\App\ProductMetadataInterface');
        return $productMetadata->getVersion();
    }

    public function getOfferApi()
    {
        if ($this->getChecksanbox() == 1) {
            return 'https://api.test.superpayments.com/v2/offers';
        } else {
            return 'https://api.superpayments.com/v2/offers';
        }
    }

    public function getPaymentApi()
    {
        if ($this->getChecksanbox() == 1) {
            return 'https://api.test.superpayments.com/v2/payments';
        } else {
            return 'https://api.superpayments.com/v2/payments';
        }
    }

    public function getRefuntApi()
    {
        if ($this->getChecksanbox() == 1) {
            return 'https://api.test.superpayments.com/v2/refunds';
        } else {
            return 'https://api.superpayments.com/v2/refunds';
        }
    }

    public function getOfferApiResponse($itemData, $url)
    {
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_USERAGENT => $this->getUserAgent(),
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($itemData, true),
            CURLOPT_HTTPHEADER => array(
                'content: application/json',
                'accept: application/json',
                'checkout-api-key: ' . $this->getApikey(),
                'Content-Type: application/json',
                'version: ' . $this->getModuleVersion(),
                'magento-version: ' . $this->getMagentoVersion()
            ),
        ));
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    public function getcurrencySymbol()
    {
        $currentCurrency = $this->_storeManager->getStore()->getCurrentCurrencyCode();
        $currency = $this->currencyCode->load($currentCurrency);
        $currencySymbol = $currency->getCurrencySymbol();
        return $currencySymbol;
    }

    public function getExternalId()
    {
        $quoteId = $this->checkoutsession->getQuote()->getId();
        return $quoteId;
    }

    public function getQuoteByExternalId($externalid)
    {
        $quote = $this->quoteFactory->create()->load($externalid);
        return $quote;
    }
}