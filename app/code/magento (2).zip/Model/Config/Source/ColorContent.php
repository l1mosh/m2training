<?php
namespace Superpayments\SuperPayment\Model\Config\Source;

class ColorContent implements \Magento\Framework\Data\OptionSourceInterface
{
 public function toOptionArray()
 {
  return [
  	['value' => 'black-white', 'label' => __('White on Black')],
    ['value' => 'orange', 'label' => __('Orange')],
    ['value' => 'yellow', 'label' => __('Yellow')], 
    ['value' => 'black-orange', 'label' => __('Orange on Black')], 
  ];
 }
}
