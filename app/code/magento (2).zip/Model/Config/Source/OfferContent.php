<?php
namespace Superpayments\SuperPayment\Model\Config\Source;

class OfferContent implements \Magento\Framework\Data\OptionSourceInterface
{
 public function toOptionArray()
 {
  return [
  	['value' => '0', 'label' => __('None')],
    ['value' => '1', 'label' => __('Home page only')],
    ['value' => '2', 'label' => __('On every page')], 
  ];
 }
}
