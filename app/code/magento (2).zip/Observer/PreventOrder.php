<?php
namespace Superpayments\SuperPayment\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderManagementInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Store\Model\StoreManagerInterface;

class PreventOrder implements ObserverInterface
{
	protected $url; 	
	protected $_actionFlag; 	
	protected $redirect; 	
	protected $_responseFactory; 	
	protected $_response; 	
	protected $quoteFactory; 	
	protected $_messageManager; 	
	protected $collectionFactory; 	
	protected $_postFactory; 	
	protected $resultFactory; 	
	protected $storeManager; 	
	protected $_helper; 	
	protected $_orderFactory; 	
	protected $_checkoutSession; 	
	protected $_pageFactory; 	
	protected $_coreRegistry; 	
	protected $messageManager; 	

public function __construct(
           \Magento\Framework\Registry $coreRegistry,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\View\Result\PageFactory $pageFactory,
        \Superpayments\SuperPayment\Helper\Data $helper,
        StoreManagerInterface $storeManager,
        \Magento\Framework\Controller\ResultFactory $resultFactory,
        \Superpayments\SuperPayment\Model\PostFactory $postFactory,
        \Superpayments\SuperPayment\Model\ResourceModel\Post\CollectionFactory $CollectionFactory,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Quote\Model\QuoteFactory $quoteFactory,
        \Magento\Framework\App\Response\Http $response,
        \Magento\Framework\App\ResponseFactory $responseFactory,
        \Magento\Framework\App\Response\RedirectInterface $redirect,
        \Magento\Framework\App\ActionFlag $actionFlag,
        \Magento\Framework\UrlInterface $url
) {
		$this->messageManager = $messageManager;
        $this->_coreRegistry = $coreRegistry;
        $this->_pageFactory = $pageFactory;
        $this->_checkoutSession = $checkoutSession;
        $this->_orderFactory = $orderFactory;
        $this->_helper = $helper;
        $this->storeManager = $storeManager;
        $this->resultFactory = $resultFactory;
        $this->_postFactory = $postFactory;
        $this->collectionFactory = $CollectionFactory;
        $this->_messageManager = $messageManager;
        $this->quoteFactory = $quoteFactory;
        $this->_response = $response;
        $this->_responseFactory = $responseFactory;
        $this->redirect = $redirect;
        $this->_actionFlag = $actionFlag;
        $this->url = $url;
}

/**
 * @param Observer $observer
 * @return $this
 */
public function execute(Observer $observer)
 {
   $order = $observer->getEvent()->getData('order');

   try {
        $quoteId = $order->getQuoteId();
        
        if ($quoteId) {
        $BaseUrl = $this->storeManager->getStore()->getBaseUrl();
        $quote = $this->quoteFactory->create()->load($quoteId);
        $post = $this->_postFactory->create();
        $collection = $this->collectionFactory->create();
        $collectionOffer = $collection->addFieldToFilter('quote_id', $quoteId)->getColumnValues('cashback_offer_id');
        isset($collectionOffer[0]) ? $cashback_offer_id = $collectionOffer[0] : $cashback_offer_id = "";
        $quoteAmount = $quote->getGrandTotal();
        $item_total = max( 0, (float) $quoteAmount );
        $item_total_minor_unit = round( $item_total * 100 );
        $ApiData = [];
        $ApiData['cashbackOfferId'] = $cashback_offer_id; 
        $ApiData['successUrl'] = $BaseUrl."checkout/onepage/success/";
        $ApiData['cancelUrl']  = $BaseUrl."checkout/cart/";
        $ApiData['failureUrl'] = $BaseUrl."checkout/cart/";
        $ApiData['minorUnitAmount'] = $item_total_minor_unit;
        $ApiData['currency'] = $this->_helper->getCurrentCurrencyCode();
        $ApiData['externalReference'] = $quoteId;
        if ($this->_helper->getChecksanbox() == 1) {
                 $ApiData['test'] = true;
            }
            else {
            $ApiData['test'] = false;
            }
        $ApiUrl = $this->_helper->getPaymentApi();
        $response = $this->_helper->getOfferApiResponse($ApiData, $ApiUrl);
        $response  = json_decode($response, true);
            $collection = $collection->addFieldToFilter('quote_id', $quoteId);
            if ($collection->count() > 0) {
              $postUpdate = $post->load($quoteId,'quote_id');
              //$postUpdate->setOrderIncrementId($this->getOrderId());
              if (isset($response['redirectUrl']) && $response['transactionId'] && $response['transactionReference']) {
              $postUpdate->setRedirectUrl($response['redirectUrl']);
              $postUpdate->setTransactionId($response['transactionId']);
              $postUpdate->setTransactionReference($response['transactionReference']);
              }

              $postUpdate->save();
            }
         $redirect = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);
         if (isset($response['redirectUrl'])) {
          //$this->_redirect($response['redirectUrl']);
       //return;
            //$this->_responseFactory->create()->setRedirect($response['redirectUrl'])->sendResponse();
             //$controller = $observer->getControllerAction();
             //$this->actionFlag->set('', \Magento\Framework\App\Action\Action::FLAG_NO_DISPATCH, true);
             $this->_actionFlag->set('', \Magento\Framework\App\Action\Action::FLAG_NO_DISPATCH, true);
             $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
              $redirect = $objectManager->get('\Magento\Framework\App\Response\Http');
      $redirect->setRedirect($BaseUrl.'superPayment/standard/redirect');
      return;
            //$observer->getControllerAction()->getResponse()->setRedirect($this->url->getUrl("superPayment/standard/redirect"));
        // $action = $observer->getEvent()->getControllerAction();

        // /**
        //  * @var $response \Magento\Framework\App\Response\Http
        //  */
        // $response = $action->getResponse();
        // $response->clearHeaders()->setNoCacheHeaders();
        // $this->redirect->redirect($response, 'customer/account/login');
        // return;
        //return $this;
            //$this->redirect->redirect($controller->getResponse(), 'https://superpayment.24livehost.com/');
              //return $this;

            //$this->redirect->redirect($response['redirectUrl']);

            //exit;
          // echo $response['redirectUrl'];
          // die('testt');
            // $redirect->setUrl($response['redirectUrl']);
            // return $redirect;
            //return $this->_response->setRedirect($response['redirectUrl']); 
        } else {
            $this->_messageManager->addErrorMessage('Please make sure payment method is configured correctly');
            $this->_redirect('checkout/cart');
            return;
        }
         return $redirect;  
        }
     // if ($orderTotal < $threshold) {
     //   $message = "Order is below the $100 minimum required!";
     //   $this->messageManager->addError(__($message));
     //   $this->_redirect('checkout/cart');
     //   return;
     // }
   } catch (\Magento\Framework\Exception\Exception $e) {
     throw new \Magento\Framework\Exception\LocalizedException(
       __($e->getMessage())
     );
   }
 }
}