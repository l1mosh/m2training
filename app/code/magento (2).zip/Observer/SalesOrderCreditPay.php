<?php
namespace Superpayments\SuperPayment\Observer;

use Magento\Framework\Event\Observer as EventObserver;

use Magento\Framework\Event\ObserverInterface;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Directory\Model\CurrencyFactory;
use Magento\Sales\Api\Data\OrderStatusHistoryInterface;
use Magento\Sales\Api\OrderStatusHistoryRepositoryInterface;

class SalesOrderCreditPay implements ObserverInterface
{   
	
	
	protected $storeConfig;   
	protected $currencyCode;   
	protected $collectionFactory;   
	protected $invoiceCollectionFactory;   
	protected $invoiceFactory;   
	protected $orderRepository;   
	protected $helperData;   
	protected $orderStatusRepository;   

	/**

	* @param EventObserver $observer

	* @return $this

	* @SuppressWarnings(PHPMD.CyclomaticComplexity)

	*/

	public function __construct(
	  \Magento\Framework\View\Element\Template\Context $context,
	  StoreManagerInterface $storeConfig,
	  CurrencyFactory $currencyFactory,
	  \Superpayments\SuperPayment\Model\ResourceModel\Post\CollectionFactory $CollectionFactory,
	  \Magento\Sales\Model\ResourceModel\Order\Invoice\CollectionFactory $InvoicecollectionFactory,
	  \Magento\Sales\Model\Order\InvoiceFactory $InvoiceFactory,
	  \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
	  \Superpayments\Superpayment\Helper\Data $helperData,
	  OrderStatusHistoryRepositoryInterface $orderStatusRepository,
	  array $data = []
	) {
	  $this->storeConfig = $storeConfig;
	  $this->currencyCode = $currencyFactory->create();
	  $this->collectionFactory = $CollectionFactory;
	  $this->invoiceCollectionFactory = $InvoicecollectionFactory;
	  $this->invoiceFactory = $InvoiceFactory;
	  $this->orderRepository = $orderRepository;
	  $this->helperData = $helperData;
	  $this->orderStatusRepository = $orderStatusRepository;
	}

	public function execute(EventObserver $observer)

	{

		 $creditmemo = $observer->getEvent()->getCreditmemo();
		 $order = $creditmemo->getOrder();
		 $payment = $order->getPayment();
		 if ( $payment->getMethod() == "super_payment_gateway" ) {
		   $collectionAmountaftSaving = $this->collectionFactory->create()->addFieldToFilter('order_increment_id', $order->getId())->getColumnValues('amountafter_saving');
		   $collectionSavingAmount = $this->collectionFactory->create()->addFieldToFilter('order_increment_id', $order->getId())->getColumnValues('saving_amount');
		   isset($collectionAmountaftSaving[0]) ? $grand_total = $collectionAmountaftSaving[0] : $grand_total = "";
		   isset($collectionSavingAmount[0]) ? $saving_amount = $collectionSavingAmount[0] : $saving_amount = "";
		   $collection = $this->collectionFactory->create();

		   $collectionAmountafter = $this->collectionFactory->create()->addFieldToFilter('order_increment_id', $order->getId())->getColumnValues('amountafter_saving');
		   $collectionTransactionId = $this->collectionFactory->create()->addFieldToFilter('order_increment_id', $order->getId())->getColumnValues('transaction_id');
		   isset($collectionAmountafter[0]) ? $amountafter_saving = $collectionAmountafter[0] : $amountafter_saving = "";
		   isset($collectionTransactionId[0]) ? $transaction_id = $collectionTransactionId[0] : $transaction_id = "";
		   $item_total = max( 0, (float) $amountafter_saving );
		   $item_total_minor_unit = round( $item_total * 100 );
		   $ApiData = [];
		   $ApiData['transactionId'] = $transaction_id;
		   $ApiData['minorUnitAmount'] = $item_total_minor_unit;
		   $ApiData['currency'] = $this->helperData->getCurrentCurrencyCode();
		   $ApiData['externalReference'] = $order->getId();
		   $ApiUrl = $this->helperData->getRefuntApi();
		   $response1 = $this->helperData->getOfferApiResponse($ApiData, $ApiUrl);
		   $response  = json_decode($response1, true);
		   $w1 = 0;
		   $w2 = 0;
		   $word = "refunded";
		   $word1 = "Refund Transaction Id";
		   $word2 = "Refund Transaction Reference";
		   foreach ($order->getStatusHistoryCollection() as $status) {
			if ($status->getComment()) {
			  if (str_contains($status->getComment(), $word)) { 
				$commentId = $status->getEntityId();
				try {
				  $orderStatusCommentObject = $this->orderStatusRepository->get($commentId);
				  $result = $this->orderStatusRepository->delete($orderStatusCommentObject);
				  $order->addStatusHistoryComment('We refunded '.$this->helperData->getcurrencySymbol().number_format($amountafter_saving, 2, '.', '').' offline.');
				} catch (NoSuchEntityException $exception) {
				  $this->logger->error($exception->getMessage());
				}
			  }
			  if (str_contains($status->getComment(), $word1)) { 
				$w1 = 1;
			  }
			  if (str_contains($status->getComment(), $word2)) { 
				$w2 = 1;
			  }
			}
		  }
		  if ($w1 != 1) {
			$order->addStatusHistoryComment('Refund Transaction Id : '.$response['transactionId']);
		  }
		  if ($w2 != 1) {
			$order->addStatusHistoryComment('Refund Transaction Reference : '.$response['transactionReference']);
		  }
		  $order->setBaseTotalRefunded($grand_total);
		  $order->setTotalRefunded($grand_total);
		  $order->setGrandTotal($grand_total);
		  $order->setBaseGrandTotal($grand_total);
		  $order->save();
		  $creditmemo->setBaseTotalRefunded($grand_total);
		  $creditmemo->setTotalRefunded($grand_total);
		  $creditmemo->setGrandTotal($grand_total);
		  $creditmemo->setBaseGrandTotal($grand_total);
		  $creditmemo->setDiscountAmount(-$saving_amount);
		  $creditmemo->setBaseDiscountAmount(-$saving_amount);
		  $creditmemo->save();
		  $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/custom_memo_1.log');
		  $logger = new \Zend_Log();
		  $logger->addWriter($writer);
		  $logger->info($response1);
		}
	}    

}