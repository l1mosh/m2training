<?php
namespace Superpayments\SuperPayment\Observer;

use Magento\Framework\Event\Observer as EventObserver;

use Magento\Framework\Event\ObserverInterface;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Directory\Model\CurrencyFactory;

class SalesOrderInvoicePay implements ObserverInterface

{   


	protected $storeConfig;
	protected $currencyCode;
	protected $collectionFactory;
	protected $invoiceCollectionFactory;
	protected $invoiceFactory;
	protected $orderRepository;
	/**

	* @param EventObserver $observer

	* @return $this

	* @SuppressWarnings(PHPMD.CyclomaticComplexity)

	*/

	public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		StoreManagerInterface $storeConfig,
		CurrencyFactory $currencyFactory,
		\Superpayments\SuperPayment\Model\ResourceModel\Post\CollectionFactory $CollectionFactory,
		\Magento\Sales\Model\ResourceModel\Order\Invoice\CollectionFactory $InvoicecollectionFactory,
		\Magento\Sales\Model\Order\InvoiceFactory $InvoiceFactory,
		\Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
		array $data = []
	) {
		$this->storeConfig = $storeConfig;
		$this->currencyCode = $currencyFactory->create();
		$this->collectionFactory = $CollectionFactory;
		$this->invoiceCollectionFactory = $InvoicecollectionFactory;
		$this->invoiceFactory = $InvoiceFactory;
		$this->orderRepository = $orderRepository;
	}

	public function execute(EventObserver $observer)

	{

	   $invoice = $observer->getEvent()->getInvoice();

	   $order = $invoice->getOrder();
			   $payment = $order->getPayment();
			if ( $payment->getMethod() == "super_payment_gateway" ) {
	   $collectionAmountaftSaving = $this->collectionFactory->create()->addFieldToFilter('order_increment_id', $order->getId())->getColumnValues('amountafter_saving');
	   $collectionSavingAmount = $this->collectionFactory->create()->addFieldToFilter('order_increment_id', $order->getId())->getColumnValues('saving_amount');
	   isset($collectionAmountaftSaving[0]) ? $grand_total = $collectionAmountaftSaving[0] : $grand_total = "";
	   isset($collectionSavingAmount[0]) ? $saving_amount = $collectionSavingAmount[0] : $saving_amount = "";
	   $currentCurrency = $this->storeConfig->getStore()->getCurrentCurrencyCode();
	   $currency = $this->currencyCode->load($currentCurrency);
	   $currencySymbol = $currency->getCurrencySymbol();
	   /* reset total_paid & base_total_paid of order */
	   $invoice->setGrandTotal($grand_total);
	   $invoice->setBaseGrandTotal($grand_total);
	   $invoice->setDiscountAmount(-$saving_amount);
	   $invoice->save();

	   $order->setTotalPaid($grand_total);
	   $order->setBaseTotalPaid($grand_total);
	   $order->save();
	}
	}    

}