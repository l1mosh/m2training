<?php

namespace Superpayments\SuperPayment\Plugin\Model\Session;

use Magento\Checkout\Model\Session;
use Magento\Checkout\Model\Session\SuccessValidator;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\DataObject;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Superpayments\SuperPayment\Helper\Data;

class SuccessValidatorPlugin
{
    /** @var RequestInterface */
    protected $request;

    /**
     * @var Session
     */
    protected $checkoutSession;

    /**
     * @var CollectionFactory
     */
    protected $orderCollectionFactory;

    /**
     * @var Superpayments\SuperPayment\Helper\Data
     */
    protected $_helper;

    /**
     * @param RequestInterface $request
     * @param Session $checkoutSession
     * @param CollectionFactory $orderCollectionFactory
     * @param Data $helper
     */
    public function __construct(
        RequestInterface  $request,
        Session           $checkoutSession,
        CollectionFactory $orderCollectionFactory,
        Data              $helper

    )
    {
        $this->request = $request;
        $this->checkoutSession = $checkoutSession;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->_helper = $helper;
    }

    /**
     * @param SuccessValidator $subject
     * @param $result
     * @return mixed|true
     */
    public function afterIsValid(SuccessValidator $subject, $result)
    {

        $id = $this->request->getParam('id');

        if ($id) {
            /** @var Order $order */
            $order = $this->getOrderByIncrementId($id);

            if ($order->getId()) {
                $this->checkoutSession
                    ->setLastOrderId($order->getId())
                    ->setLastRealOrderId($order->getIncrementId())
                    ->setLastOrderStatus($order->getStatus());
                return true;
            }
            $collection = $this->orderCollectionFactory->create();
            $collection = $collection->addFieldToFilter('quote_id', $order->getQuoteId());
            if ($collection->count() > 0) {
                $collectionOffer = $collection->addFieldToFilter('quote_id', $order->getQuoteId())->getColumnValues('cashback_offer_id');
                isset($collectionOffer[0]) ? $cashback_offer_id = $collectionOffer[0] : $cashback_offer_id = "";
                $ApiUrl = $this->_helper->getOfferApi();
                $ApiUrl = $ApiUrl . "/" . $cashback_offer_id . "/expire";
                $ApiData = array();
                $responseexpire = $this->_helper->getOfferApiResponse($ApiData, $ApiUrl);
                $writer = new \Zend_Log_Writer_Stream(BP . "/var/log/super_payment_offerAPI.log");
                $logger = new \Zend_Log();
                $logger->addWriter($writer);
                $logger->info("Offer Expire Response - " . $responseexpire);
            }
        }

        return $result;
    }

    /**
     * @param $increment_id
     * @return DataObject
     */
    public function getOrderByIncrementId($increment_id)
    {
        $collection = $this->orderCollectionFactory->create();
        $collection->addFieldToFilter('increment_id', $increment_id)
            ->setPageSize(1)
            ->setCurPage(1);
        return $collection->getFirstItem();
    }
}
