<?php

namespace Superpayments\SuperPayment\Plugin\Order\Email\Container;

use Magento\Checkout\Model\Session;
use Magento\Sales\Model\Order\Email\Container\OrderIdentity;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\DataObject;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Superpayments\SuperPayment\Helper\Data;

class OrderIdentityPlugin
{
    /** @var RequestInterface */
    protected $request;

    /**
     * @var Session
     */
    protected $checkoutSession;

    /**
     * @var CollectionFactory
     */
    protected $orderCollectionFactory;

    /**
     * @var Superpayments\SuperPayment\Helper\Data
     */
    protected $_helper;

    /**
     * @param RequestInterface $request
     * @param Session $checkoutSession
     * @param CollectionFactory $orderCollectionFactory
     * @param Data $helper
     */
    public function __construct(
        RequestInterface     $request,
        Session              $checkoutSession,
        CollectionFactory    $orderCollectionFactory,
        Data                 $helper
    )
    {
        $this->request = $request;
        $this->checkoutSession = $checkoutSession;
        $this->orderCollectionFactory = $orderCollectionFactory;
        $this->_helper = $helper;
    }

    /**
     * @param OrderIdentity $subject
     * @param $result
     * @return mixed|true
     */
    public
    function afterIsEnabled(OrderIdentity $subject, $result)
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/superlog.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        $quote = $this->checkoutSession->getQuote();
        $method = $quote->getPayment()->getMethod();

        $logger->info('Payment Method : ' . $method);
        if ($method == 'super_payment_gateway') {
            return false;
        }else {
            return true;
        }
    }
}
