<?php 
namespace Superpayments\SuperPayment\ViewModel;

use Psr\Log\LoggerInterface;
use Magento\Framework\App\Request\Http;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Directory\Model\CurrencyFactory;

class BasysInfo implements \Magento\Framework\View\Element\Block\ArgumentInterface
{
    protected $logger;
    protected $request;
    protected $order;
    protected $collectionFactory;
    protected $storeConfig;
    protected $currencyCode;

    public function __construct(
        LoggerInterface $logger,
        Http $request,
        \Magento\Sales\Api\OrderRepositoryInterface $order,        
        \Superpayments\SuperPayment\Model\ResourceModel\Post\CollectionFactory $CollectionFactory,
        StoreManagerInterface $storeConfig,
        CurrencyFactory $currencyFactory

    ) {
        $this->logger = $logger;
        $this->request = $request;
        $this->order = $order;
        $this->collectionFactory = $CollectionFactory;
        $this->storeConfig = $storeConfig;
        $this->currencyCode = $currencyFactory->create();
    }
    public function getSavingPercentage()
    {
        $collection_percentage = "";
        $order_id = $this->request->getParam('order_id');
        $order = $this->order->get($order_id);
        $payment = $order->getPayment();
        if ( $payment->getMethod() == "super_payment_gateway" ) {
        $collection = $this->collectionFactory->create();
        $collectionPercentage = $collection->addFieldToFilter('order_increment_id', $order_id)->getColumnValues('saving_percentage');
        isset($collectionPercentage[0]) ? $collection_percentage = $collectionPercentage[0] : $collection_percentage = "";
        }
        return $collection_percentage;
    }

    public function getSavingAmount()
    {
        $amountafter_saving = "";
        $order_id = $this->request->getParam('order_id');
        $order = $this->order->get($order_id);
        $payment = $order->getPayment();
        if ( $payment->getMethod() == "super_payment_gateway" ) {
        $collection = $this->collectionFactory->create();
        $collectionSaving = $collection->addFieldToFilter('order_increment_id', $order_id)->getColumnValues('amountafter_saving');
        isset($collectionSaving[0]) ? $amountafter_saving = $collectionSaving[0] : $amountafter_saving = "";
        }
        return $amountafter_saving;
    }
    public function getQouteID()
    {
        $order_id = $this->request->getParam('order_id');
        $order = $this->order->get($order_id);
        $_orderID = $order->getIncrementId();
        return $_orderID;
    }

        public function getcurrencySymbol()
    {
        $currentCurrency = $this->storeConfig->getStore()->getCurrentCurrencyCode();
        $currency = $this->currencyCode->load($currentCurrency);
        $currencySymbol = $currency->getCurrencySymbol();
        return $currencySymbol;
    }
}