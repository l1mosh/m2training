var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/model/checkout-data-resolver': {
                'Superpayments_SuperPayment/js/model/checkout-data-resolver': true
            }
        }
    }
};
