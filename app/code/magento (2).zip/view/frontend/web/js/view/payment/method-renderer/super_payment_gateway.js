/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*browser:true*/
/*global define*/
define(
    [
        'jquery',
        'mage/url',
        'Magento_Checkout/js/view/payment/default',
        'Magento_Checkout/js/model/quote'

        ],
    function ($,url, Component, quote) {
        'use strict';

        return Component.extend({
            defaults: {
                redirectAfterPlaceOrder: false,
                template: 'Superpayments_SuperPayment/payment/form'
            },

            initObservable: function () {

                this._super()
                return this;
            },

            getCode: function() {
                return 'super_payment_gateway';
            },

            getLogo: function(){
                return window.checkoutConfig.payment.super_payment_gateway.paymentlogo
            },
            getData: function() {
                return {
                    'method': this.item.method
                };
            },
            getDiscount(){
                 //var data = "";
                        var customLink =  url.build('superpayment/standard/discount');
                        $('body').trigger('processStart');
                         $(".superpaymentmethod").hide();
                        console.log(customLink);
                        
                        $.ajax({
                            url : customLink,
                            dataType : 'json',
                            type : 'POST',
                            async: false,
                            cache: false,
                            success : function(done)
                            {
                                $('body').trigger('processStop');
                                if(done.errorMessage)
								{
									console.log(done);
									alert(done.errorMessage);
								}	
								else
								{	
									$(".superpaymentmethod").show();
									var description = done.description;
									var title = done.title;
									$(".superblockcontent").html(description);
									$(".payment_title").html(title);
								}
                            },
                            error : function(res)
                            {
                                console.log('error now');
                            }
                        });
                },
        customplaceOrder: function () {
            var serviceUrl = url.build('superpayment/standard/redirect');
               $.ajax({
                url: serviceUrl,
                type: 'POST',
                dataType: 'json',
                async: false,
                cache: false,
            complete: function(responseData) {
                var responseData = JSON.parse(responseData.responseText);
                if (responseData.success) {
                    var redirect_url = responseData.redirect_url; 
                    $.mage.redirect(redirect_url); 
                }
				else
				{
					alert(responseData.apiError);
				}	
            },
            error: function (xhr, status, errorThrown) {
                console.log('Error happens. Try again.');
            }
            });
            //$.mage.redirect(window.checkoutConfig.payment.super_payment_gateway.redirectUrl);
            //$.mage.redirect('https://superpayment.24livehost.com/');
            return false;
        }

    });
});